package Dao;

import Entity.User;

import java.util.List;

public interface DaoTest {
     List<User> getString();
}
